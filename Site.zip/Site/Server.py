from http.server import HTTPServer, CGIHTTPRequestHandler
server_data = ('127.0.0.1', 9090)
server = HTTPServer(server_data, CGIHTTPRequestHandler)
print("Hi!\n")
server.serve_forever()